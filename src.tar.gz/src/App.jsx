import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import React, { useState, useEffect, Suspense, lazy } from 'react';
import { GoogleOAuthProvider } from '@react-oauth/google';
import { API_BASE } from './api';

import Login from './pages/Login';
import Register from './pages/Register';
import GoogleCallback from './pages/GoogleCallback';
import Dashboard from './pages/Dashboard';
import Layout from './components/Layout';
import LandingPage from './pages/LandingPage';
import AdminDashboard from './pages/AdminDashboard';
import ScrollToTop from './components/ScrollToTop';
import UpgradeRequired from './pages/UpgradeRequired';

const DebateArena = lazy(() => import('./pages/DebateArena'));
const Results = lazy(() => import('./pages/Results'));
const Analytics = lazy(() => import('./pages/Analytics'));
const Leaderboard = lazy(() => import('./pages/Leaderboard'));
const PersonaPicker = lazy(() => import('./pages/PersonaPicker'));
const PersonaDebate = lazy(() => import('./pages/PersonaDebate'));
const MockUN = lazy(() => import('./pages/MockUN'));
const Settings = lazy(() => import('./pages/Settings'));
const ConversationalAgent = lazy(() => import('./pages/ConversationalAgent'));
const DebateInstructions = lazy(() => import('./pages/DebateInstructions'));
const VocabTrainer = lazy(() => import('./pages/VocabTrainer'));
const WordScramble = lazy(() => import('./pages/WordScramble'));
const PremiumSuccess = lazy(() => import('./pages/PremiumSuccess'));
const Diplomat365 = lazy(() => import('./pages/diplomat365/D365App'));
const MUN30 = lazy(() => import('./pages/mun30/MUN30App'));
const GTalkCohort = lazy(() => import('./pages/GTalkCohort'));
const MUNMentorRegister = lazy(() => import('./pages/MUNMentorRegister'));
const MiniMunRegister = lazy(() => import('./pages/MiniMunRegister'));
const IndusMunRegister = lazy(() => import('./pages/IndusMunRegister'));
const EnglishSessionRegister = lazy(() => import('./pages/EnglishSessionRegister'));
const FreedomQuizRegister = lazy(() => import('./pages/FreedomQuizRegister'));
const UNCertificateDownload = lazy(() => import('./pages/UNCertificateDownload'));
const CertificatesHub = lazy(() => import('./pages/CertificatesHub'));
const MiniMunMod1CertificateDownload = lazy(() => import('./pages/MiniMunMod1CertificateDownload'));
const MiniMunMod2CertificateDownload = lazy(() => import('./pages/MiniMunMod2CertificateDownload'));
const MiniMunMod3CertificateDownload = lazy(() => import('./pages/MiniMunMod3CertificateDownload'));

const ITORegister = lazy(() => import('./pages/ITORegister'));
const SpeechAnalysis = lazy(() => import('./pages/SpeechAnalysis'));

const OlympiadSchoolRegister = lazy(() => import('./pages/OlympiadSchoolRegister'));
const OlympiadStudentRegister = lazy(() => import('./pages/OlympiadStudentRegister'));
const OlympiadPractice = lazy(() => import('./pages/OlympiadPractice'));
const OlympiadArena = lazy(() => import('./pages/OlympiadArena'));
const CoordinatorDashboard = lazy(() => import('./pages/CoordinatorDashboard'));
const OlympiadReportCard = lazy(() => import('./pages/OlympiadReportCard'));

function App() {
  
  const [isInitializing, setIsInitializing] = useState(true);
  const [profilesToSelect, setProfilesToSelect] = useState(null); // MULTI-PROFILE STATE

  const [user, setUser] = useState(() => {
    try {
      const storedUser = localStorage.getItem('user');
      return storedUser ? JSON.parse(storedUser) : null;
    } catch {
      return null;
    }
  });

  const handleLogin = (userData) => {
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData));
  };

  const handleLogout = async () => {
    setUser(null);
    localStorage.removeItem('user');
    localStorage.removeItem('token');
  };

  const handleSwitchProfile = async () => {
    alert('You are now using direct username authentication. To switch accounts, simply log out and log in with your other username.');
  };

  const isJunior = ['Level 1', 'Level 2', 'Class 1-3', 'Class 3-5', 'KG', 'Class KG', 'KG-2', 'Class 1-5', 'Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5', 'kg'].includes(user?.classLevel);
  const themeClass = isJunior ? 'theme-junior' : 'theme-senior';

  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  // Sync user profile on mount
  useEffect(() => {
    if (user?.studentId) {
      fetch(`${API_BASE}/api/me/${user.studentId}`)
        .then(res => res.json())
        .then(data => {
          if (data.user) {
            // Merge with existing user data (to keep token if we stored it there, though we use localStorage)
            const updatedUser = { ...user, ...data.user };
            setUser(updatedUser);
            localStorage.setItem('user', JSON.stringify(updatedUser));
          }
        })
        .catch(err => console.error("Failed to sync user profile:", err));
    }
  }, []);

  useEffect(() => {
    document.body.className = themeClass;
  }, [themeClass]);

  useEffect(() => {
    // Standard Custom JWT LocalStorage check
    try {
      const storedUser = localStorage.getItem('user');
      const storedToken = localStorage.getItem('token');
      
      if (storedUser && storedToken) {
        // Bug #7 fix: JSON.parse can throw on corrupted data; catch it to avoid
        // an unhandled exception that leaves the app stuck on the spinner.
        try {
          setUser(JSON.parse(storedUser));
        } catch (e) {
          console.error("Corrupted user in localStorage", e);
          setUser(null);
          localStorage.removeItem('user');
          localStorage.removeItem('token');
        }
      } else if (window.location.pathname !== '/' && window.location.pathname !== '/login' && !window.location.pathname.includes('/register')) {
        // Clear invalid state
        setUser(null);
        localStorage.removeItem('user');
        localStorage.removeItem('token');
      }
    } catch (e) {
      // Corrupted localStorage — clear it and start fresh
      setUser(null);
      localStorage.removeItem('user');
      localStorage.removeItem('token');
    }
    setIsInitializing(false);

    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Loading spinner for lazy-loaded pages
  const PageLoader = () => (
    <div style={{ display: 'flex', height: '100vh', width: '100%', justifyContent: 'center', alignItems: 'center', background: '#06080F' }}>
      <div className="animate-spin" style={{ width: 44, height: 44, border: '3px solid rgba(255,255,255,0.1)', borderTopColor: '#F97316', borderRadius: '50%' }} />
    </div>
  );


  if (isInitializing) {
    return <PageLoader />;
  }

  // --- MULTI-PROFILE SELECTION UI ---
  if (profilesToSelect) {
    return (
      <div style={{ minHeight: '100vh', background: '#06080f', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '2rem', fontFamily: "'Google Sans', sans-serif" }}>
         <h1 style={{ color: '#fff', fontSize: '3rem', fontWeight: 800, marginBottom: '3rem', letterSpacing: '-0.02em', textAlign: 'center' }}>Who's Learning?</h1>
         
         <div style={{ display: 'flex', gap: '2rem', flexWrap: 'wrap', justifyContent: 'center', maxWidth: '900px' }}>
            {profilesToSelect.map(profile => (
               <div 
                  key={profile.studentId}
                  onClick={() => {
                     handleLogin({
                        name: profile.name,
                        username: profile.studentId,
                        classLevel: profile.classLevel, 
                        assignedAgentId: profile.assignedAgentId,
                        id: profile.id,
                        studentId: profile.studentId,
                        avatar: profile.avatar
                     });
                     setProfilesToSelect(null);
                     window.location.href = '/dashboard';
                  }}
                  style={{ 
                     display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1rem', 
                     cursor: 'pointer', transition: 'transform 0.2s', width: '140px' 
                  }}
                  onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.05)'}
                  onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}
               >
                  <div style={{ width: '120px', height: '120px', borderRadius: '24px', background: '#1e293b', border: '2px solid rgba(255,255,255,0.1)', overflow: 'hidden', display: 'flex', justifyContent: 'center', alignItems: 'center', boxShadow: '0 10px 30px rgba(0,0,0,0.5)' }}>
                      {profile.avatar ? (
                         <img src={profile.avatar} alt={profile.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                      ) : (
                         <span style={{ fontSize: '3rem', color: '#94a3b8', fontWeight: 800 }}>{profile.name.charAt(0).toUpperCase()}</span>
                      )}
                  </div>
                  <span style={{ color: '#e2e8f0', fontSize: '1.2rem', fontWeight: 600, textAlign: 'center' }}>{profile.name}</span>
               </div>
            ))}

            {/* ADD LEARNER BUTTON */}
            <div 
               onClick={() => { window.location.href = '/register?step=details'; }}
               style={{ 
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '1rem', 
                  cursor: 'pointer', transition: 'transform 0.2s', width: '140px' 
               }}
               onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.05)'}
               onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'}
            >
               <div style={{ width: '120px', height: '120px', borderRadius: '24px', background: 'transparent', border: '2px dashed rgba(255,255,255,0.3)', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                  <span style={{ fontSize: '4rem', color: 'rgba(255,255,255,0.5)', fontWeight: 300, lineHeight: 1 }}>+</span>
               </div>
               <span style={{ color: '#94a3b8', fontSize: '1.2rem', fontWeight: 600, textAlign: 'center' }}>Add Learner</span>
            </div>
         </div>
      </div>
    );
  }


  return (
    <GoogleOAuthProvider clientId={import.meta.env.VITE_GOOGLE_CLIENT_ID}>
      <Router>
        <ScrollToTop />
        <div className={themeClass}>
        <Suspense fallback={<PageLoader />}>
          <Routes>
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/" element={!user ? <LandingPage /> : <Navigate to="/dashboard" />} />
            <Route path="/login" element={!user ? <Login onLogin={handleLogin} /> : <Navigate to="/dashboard" />} />
            <Route path="/register" element={
              user && !window.location.search.includes('step=details')
                ? <Navigate to="/dashboard" />
                : <Register onLogin={handleLogin} />
            } />
            <Route path="/auth/google/callback" element={<GoogleCallback onLogin={handleLogin} />} />
            <Route path="/google-callback" element={<GoogleCallback onLogin={handleLogin} />} />
            
            <Route path="/olympiad/school-registration" element={<OlympiadSchoolRegister />} />
            <Route path="/olympiad/student-registration" element={<Navigate to="/register" />} />
            <Route path="/coordinator-dashboard" element={<CoordinatorDashboard />} />
            
            <Route element={<Layout user={user} onLogout={handleLogout} onSwitchProfile={handleSwitchProfile} />}>
              <Route path="/dashboard" element={user ? <Dashboard user={user} setUser={setUser} /> : <Navigate to="/" />} />
              <Route path="/debate" element={user ? <DebateArena user={user} /> : <Navigate to="/" />} />
              <Route path="/results/:sessionId" element={user ? <Results user={user} /> : <Navigate to="/" />} />
              <Route path="/analytics" element={user ? <Analytics user={user} /> : <Navigate to="/" />} />
              <Route path="/leaderboard" element={user ? <Leaderboard user={user} /> : <Navigate to="/" />} />
              <Route path="/persona" element={user ? <PersonaPicker user={user} /> : <Navigate to="/" />} />
              <Route path="/persona-debate" element={user ? <PersonaDebate user={user} /> : <Navigate to="/" />} />
              <Route path="/mock-un" element={user ? <MockUN user={user} /> : <Navigate to="/" />} />
              <Route path="/settings" element={user ? <Settings user={user} setUser={setUser} /> : <Navigate to="/" />} />
              <Route path="/premium-success" element={user ? <PremiumSuccess user={user} /> : <Navigate to="/" />} />
              <Route path="/conversational-agent" element={user ? <ConversationalAgent user={user} /> : <Navigate to="/" />} />
              <Route path="/speech-coach" element={user ? <ConversationalAgent user={user} agentId="agent_7601krh244qdes5s5db2rjhn1kt4" mode="speech-coach" /> : <Navigate to="/" />} />
              <Route path="/speech-analysis" element={user ? <SpeechAnalysis user={user} /> : <Navigate to="/" />} />
              <Route path="/debate-instructions" element={user ? <DebateInstructions user={user} /> : <Navigate to="/" />} />
              <Route path="/vocab-trainer" element={user ? <VocabTrainer user={user} /> : <Navigate to="/" />} />
              <Route path="/word-scramble" element={user ? <WordScramble user={user} /> : <Navigate to="/" />} />
              <Route path="/diplomat365/*" element={user ? (user.subscription_plan === 'max' ? <Diplomat365 user={user} /> : <Navigate to="/upgrade?feature=diplomat365" />) : <Navigate to="/" />} />
              <Route path="/mun30/*" element={user ? (['pro','max'].includes(user.subscription_plan) ? <MUN30 user={user} /> : <Navigate to="/upgrade?feature=mun30" />) : <Navigate to="/" />} />
              <Route path="/cohort" element={user ? <GTalkCohort user={user} /> : <Navigate to="/" />} />
              <Route path="/mun-mentor" element={user ? <MUNMentorRegister user={user} /> : <Navigate to="/" />} />
              <Route path="/mini-mun" element={user ? <MiniMunRegister user={user} /> : <Navigate to="/" />} />
              <Route path="/indus-mun" element={user ? <IndusMunRegister user={user} /> : <Navigate to="/" />} />
              <Route path="/english-session" element={user ? <EnglishSessionRegister user={user} /> : <Navigate to="/" />} />
              <Route path="/freedom-quiz" element={user ? <FreedomQuizRegister user={user} /> : <Navigate to="/" />} />

              <Route path="/olympiad/practice" element={user ? <OlympiadPractice user={user} /> : <Navigate to="/" />} />
              <Route path="/olympiad/arena" element={user ? <OlympiadArena user={user} /> : <Navigate to="/" />} />
              <Route path="/olympiad/report-card" element={user ? <OlympiadReportCard user={user} /> : <Navigate to="/" />} />

              <Route path="/ito-register" element={user ? <ITORegister user={user} /> : <Navigate to="/" />} />
              <Route path="/certificates" element={user ? <CertificatesHub /> : <Navigate to="/" />} />
              <Route path="/certificates/model-un-quiz" element={user ? <UNCertificateDownload /> : <Navigate to="/" />} />
              <Route path="/quiz-certificate" element={user ? <UNCertificateDownload /> : <Navigate to="/" />} />
              <Route path="/minimun-mod1-certificate" element={user ? <MiniMunMod1CertificateDownload /> : <Navigate to="/" />} />
              <Route path="/minimun-mod2-certificate" element={user ? <MiniMunMod2CertificateDownload /> : <Navigate to="/" />} />
              <Route path="/minimun-mod3-certificate" element={user ? <MiniMunMod3CertificateDownload /> : <Navigate to="/" />} />
              <Route path="/upgrade" element={user ? <UpgradeRequired user={user} /> : <Navigate to="/" />} />
            </Route>

            {/* Catch-all → landing page */}
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </Suspense>
      </div>
      {isOffline && (
        <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, background: '#ef4444', color: 'white', padding: '0.5rem', textAlign: 'center', zIndex: 9999, fontSize: '0.875rem', fontWeight: 600 }}>
          ⚠️ Poor internet connection. Please check your network.
        </div>
      )}
    </Router>
    </GoogleOAuthProvider>
  );
}

export default App;
