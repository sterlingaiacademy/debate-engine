import { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useGoogleLogin } from '@react-oauth/google';
import { ArrowRight, Sparkles, Zap, Trophy } from 'lucide-react';
import logoImg from '../assets/logo.png';

const GOOGLE_SANS = "'Google Sans', 'Plus Jakarta Sans', 'Product Sans', system-ui, sans-serif";

import { API_BASE } from '../api';

export default function Login({ onLogin }) {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [authMethod, setAuthMethod] = useState(null); // 'google' | 'direct'
  const [usernameFormatError, setUsernameFormatError] = useState('');

  // Add detection for mobile app
  const isMobileApp = typeof window !== 'undefined' && window.isReactNativeWebView;

  useEffect(() => {
    if (username.length > 0) {
      if (username.startsWith('.') || username.endsWith('.')) setUsernameFormatError('Cannot start or end with a dot');
      else if (username.includes('..')) setUsernameFormatError('Cannot contain consecutive dots');
      else if (/^[_.]+$/.test(username)) setUsernameFormatError('Must contain at least one letter or number');
      else setUsernameFormatError('');
    } else {
      setUsernameFormatError('');
    }
  }, [username]);

  // Google Sign-In (Web popup flow)
  const googleLogin = useGoogleLogin({
    prompt: 'select_account',
    onSuccess: async (tokenResponse) => {
      setLoading(true);
      setAuthMethod('google');
      setError('');
      try {
        const res = await fetch(`${API_BASE}/api/auth/google`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ access_token: tokenResponse.access_token }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Google login failed');
        localStorage.setItem('token', data.token);
        onLogin(data.user);
        navigate('/dashboard');
      } catch (err) {
        setError(err.message || 'Google sign-in failed. Are you registered?');
      } finally {
        setLoading(false);
        setAuthMethod(null);
      }
    },
    onError: () => setError('Google sign-in was unsuccessful.')
  });

  const handleGoogleLogin = () => {
    if (window.isReactNativeWebView && window.ReactNativeWebView) {
       window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'GOOGLE_LOGIN_NATIVE' }));
       return;
    }
    const clientId = '624023459084-o1l7b425m8sqo35o25hf3jllrj0165oo.apps.googleusercontent.com';
    const redirectUri = encodeURIComponent('https://graceandforce.com/google-callback');
    window.location.href = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${clientId}&redirect_uri=${redirectUri}&response_type=token&scope=email%20profile&prompt=select_account`;
  };

  const handleGoogleButtonClick = () => {
    if (isMobileApp) {
      handleGoogleLogin();
    } else {
      googleLogin();
    }
  };

  // Username + Password Sign-In
  const handleSubmit = async () => {
    setError('');
    if (!username) { setError('Please provide a username or email.'); return; }
    if (!username.toUpperCase().startsWith('COORD-') && !password) { setError('Please provide both username and password.'); return; }
    if (usernameFormatError) { setError('Username format is invalid.'); return; }

    if (username.toUpperCase().startsWith('COORD-')) {
       localStorage.setItem('coordinatorId', username.toUpperCase());
       navigate('/coordinator-dashboard');
       return;
    }

    setAuthMethod('credentials');
    setLoading(true);
    try {
      // ── Check admin credentials first ──
      const adminRes = await fetch(`${API_BASE}/api/admin/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      if (adminRes.ok) {
        const adminData = await adminRes.json();
        if (adminData.isAdmin) {
          localStorage.setItem('adminToken', adminData.token);
          navigate('/admin');
          return;
        }
      }

      // ── Regular user login ──
      const res = await fetch(`${API_BASE}/api/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ studentId: username, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Login failed');

      localStorage.setItem('token', data.token);
      onLogin(data.user);
      navigate('/dashboard');
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };


  return (
    <div style={{
      display: 'flex', minHeight: '100vh', width: '100%',
      fontFamily: GOOGLE_SANS, background: '#06080F', position: 'relative', overflow: 'auto'
    }}>

      {/* Background decoration */}
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, overflow: 'hidden', pointerEvents: 'none', zIndex: 0 }}>
        <div style={{ position: 'absolute', top: '-15%', right: '-10%', width: '500px', height: '500px', background: 'radial-gradient(circle, rgba(232,57,42,0.1) 0%, transparent 70%)', borderRadius: '50%' }} />
        <div style={{ position: 'absolute', bottom: '-15%', left: '-10%', width: '600px', height: '600px', background: 'radial-gradient(circle, rgba(249,115,22,0.08) 0%, transparent 70%)', borderRadius: '50%' }} />
        <div style={{ position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(rgba(255,255,255,0.01) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.01) 1px, transparent 1px)', backgroundSize: '48px 48px' }} />
      </div>

      {/* LEFT PANE */}
      <div className="login-left-pane" style={{
        flex: 1, position: 'relative', zIndex: 1,
        background: 'linear-gradient(160deg, rgba(255,255,255,0.01) 0%, rgba(255,255,255,0.0) 100%)',
        borderRight: '1px solid rgba(255,255,255,0.05)',
        display: 'flex', flexDirection: 'column', padding: '2.5rem 3rem',
      }}>
        <div style={{ marginBottom: '2rem' }}>
          <img src={logoImg} alt="G Force AI" style={{ height: 48, width: 'auto', objectFit: 'contain' }} />
        </div>

        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', maxWidth: '520px' }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
            background: 'rgba(249,115,22,0.1)', border: '1px solid rgba(249,115,22,0.2)',
            padding: '0.45rem 1rem', borderRadius: '99px', fontSize: '0.825rem',
            fontWeight: 600, marginBottom: '1.5rem', color: '#ffedd5', width: 'fit-content'
          }}>
            <Sparkles size={14} color="#F97316" /> Welcome to Grace & Force
          </div>

          <h1 style={{ fontSize: 'clamp(1.75rem, 4.5vw, 3.25rem)', fontWeight: 800, lineHeight: 1.1, marginBottom: '1.25rem', letterSpacing: '-0.03em', color: '#ffffff' }}>
            Master the{' '}
            <span style={{ background: 'linear-gradient(135deg, #FF6B5A 0%, #F97316 60%, #FBBF24 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
              Art of Debate
            </span>
          </h1>

          <p style={{ fontSize: '1.05rem', color: '#94a3b8', lineHeight: 1.7, marginBottom: '2.5rem', fontWeight: 400 }}>
            Engage with advanced AI personas, refine your argumentation skills, and climb the global leaderboards in real-time.
          </p>

          <div style={{ display: 'flex', gap: '2rem', marginBottom: '3rem' }}>
            {[
              { icon: <Zap size={16} color="#F97316" />, label: 'Real-time Analytics', bg: 'rgba(249,115,22,0.15)' },
              { icon: <Trophy size={16} color="#E8392A" />, label: 'Global Ranking', bg: 'rgba(232,57,42,0.15)' },
            ].map(({ icon, label, bg }) => (
              <div key={label} style={{ display: 'flex', alignItems: 'center', gap: '0.55rem', color: '#e2e8f0', fontSize: '0.9rem', fontWeight: 600 }}>
                <div style={{ width: '30px', height: '30px', borderRadius: '50%', background: bg, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {icon}
                </div>
                {label}
              </div>
            ))}
          </div>
        </div>

        <div style={{ fontSize: '0.8rem', color: '#64748b', marginTop: 'auto' }}>
          © 2026 G Force AI. All rights reserved.
        </div>
      </div>

      {/* RIGHT PANE */}
      <div className="login-right-pane" style={{
        flex: 1, position: 'relative', zIndex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem',
      }}>
        <div style={{
          width: '100%', maxWidth: '440px',
          background: 'rgba(255, 255, 255, 0.02)', backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)',
          border: '1px solid rgba(255, 255, 255, 0.05)', borderRadius: '24px', padding: '2.5rem',
          boxShadow: '0 12px 40px rgba(0,0,0,0.3)',
        }}>
          <div className="mobile-logo" style={{ marginBottom: '2rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.75rem' }}>
            <img src={logoImg} alt="G Force AI" style={{ height: 40, width: 'auto', objectFit: 'contain' }} />
            <span style={{
              fontWeight: 900, fontSize: '1.8rem', letterSpacing: '-0.02em',
              background: 'linear-gradient(135deg, #FF6B5A, #FF6B00)',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
            }}>
              G FORCE
            </span>
          </div>

          <div style={{ marginBottom: '2rem', textAlign: 'center' }}>
            <h2 style={{ fontSize: '1.8rem', fontWeight: 800, color: '#ffffff', marginBottom: '0.5rem', letterSpacing: '-0.02em' }}>
              Welcome back
            </h2>
            <p style={{ color: '#94a3b8', fontSize: '0.95rem' }}>
              Sign in to pick up where you left off.
            </p>
          </div>

          {error && (
            <div style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)', color: '#fca5a5', padding: '0.8rem 1rem', borderRadius: '10px', fontSize: '0.9rem', marginBottom: '1.5rem', fontWeight: 500 }}>
              {error}
            </div>
          )}

          <form onSubmit={(e) => { e.preventDefault(); handleSubmit(); }} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>

            {/* Google Button */}
            <button
              type="button" onClick={() => handleGoogleButtonClick()} disabled={loading}
              style={{
                padding: '0.9rem', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px',
                background: '#ffffff', color: '#000', fontWeight: 700, fontSize: '1rem', cursor: loading ? 'not-allowed' : 'pointer',
                fontFamily: GOOGLE_SANS, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.75rem',
                boxShadow: '0 4px 14px rgba(0,0,0,0.1)', transition: 'transform 0.2s ease, box-shadow 0.2s ease'
              }}
              onMouseOver={(e) => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = '0 6px 20px rgba(255,255,255,0.1)'; }}
              onMouseOut={(e) => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = '0 4px 14px rgba(0,0,0,0.1)'; }}
            >
              <img src="https://www.svgrepo.com/show/475656/google-color.svg" alt="G" style={{ width: 20, height: 20 }} />
              {loading && authMethod === 'google' ? 'Redirecting...' : 'Sign in with Google'}
            </button>

            {/* Divider */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', margin: '0.5rem 0' }}>
              <div style={{ flex: 1, height: '1px', background: 'rgba(255,255,255,0.1)' }} />
              <span style={{ fontSize: '0.8rem', color: '#94a3b8' }}>OR CONTINUE WITH USERNAME</span>
              <div style={{ flex: 1, height: '1px', background: 'rgba(255,255,255,0.1)' }} />
            </div>

            {/* Username / Email */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
              <label style={{ fontSize: '0.85rem', fontWeight: 600, color: '#e2e8f0' }}>Username or Email</label>
              <input
                type="text" placeholder="e.g. johndoe or user@email.com" value={username}
                onChange={e => setUsername(e.target.value.replace(/[^a-zA-Z0-9_.@-]/g, '').slice(0, 60))}
                style={{ padding: '0.85rem 1rem', background: usernameFormatError ? 'rgba(239, 68, 68, 0.05)' : 'rgba(255,255,255,0.03)', border: usernameFormatError ? '1px solid rgba(239, 68, 68, 0.5)' : '1px solid rgba(255,255,255,0.1)', borderRadius: '10px', color: '#ffffff', fontSize: '0.95rem', outline: 'none' }}
              />
              {usernameFormatError && <span style={{ color: '#fca5a5', fontSize: '0.75rem', marginTop: '0.2rem' }}>{usernameFormatError}</span>}
            </div>

            {/* Password (Hide if Coordinator) */}
            {!username.toUpperCase().startsWith('COORD-') && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <label style={{ fontSize: '0.85rem', fontWeight: 600, color: '#e2e8f0' }}>Password</label>
                </div>
                <input
                  type="password" placeholder="Enter your password" value={password}
                  onChange={e => setPassword(e.target.value)}
                  style={{ padding: '0.85rem 1rem', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '10px', color: '#ffffff', fontSize: '0.95rem', outline: 'none' }}
                />
              </div>
            )}

            {/* Submit */}
            <button
              type="submit" disabled={loading}
              style={{
                marginTop: '0.5rem', padding: '0.9rem', border: 'none', borderRadius: '12px',
                background: 'linear-gradient(135deg, #E8392A 0%, #F97316 100%)', color: '#fff',
                fontWeight: 700, fontSize: '1rem', cursor: loading ? 'not-allowed' : 'pointer',
                boxShadow: '0 4px 14px rgba(232,57,42,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem'
              }}
            >
              {loading && authMethod === 'credentials' ? 'Authenticating...' : 'Secure Sign In'}
            </button>
          </form>

          <div style={{ marginTop: '1.75rem', textAlign: 'center', fontSize: '0.85rem', color: '#94a3b8' }}>
            Don't have an account?{' '}
            <Link to="/register" style={{ color: '#F97316', textDecoration: 'none', fontWeight: 700 }}>Sign up</Link>
          </div>
          <div style={{ marginTop: '1.25rem', textAlign: 'center' }}>
            <Link to="/" style={{ color: '#64748b', fontSize: '0.8rem', textDecoration: 'none', fontWeight: 500 }}>Back to Home</Link>
          </div>
        </div>
      </div>

      <style>{`
        input:focus {
          border-color: #F97316 !important;
          box-shadow: 0 0 0 3px rgba(249, 115, 22, 0.15) !important;
          background: rgba(0, 0, 0, 0.4) !important;
        }
        @media (min-width: 901px) { .mobile-logo { display: none !important; } }
        @media (max-width: 900px) { 
          .login-left-pane { display: none !important; } 
          .login-right-pane { padding: 1.5rem !important; align-items: center !important; justify-content: center !important; }
          .login-right-pane > div { 
            padding: 2rem 1.5rem !important; 
            background: rgba(255, 255, 255, 0.03) !important; 
            backdrop-filter: blur(16px) !important;
            -webkit-backdrop-filter: blur(16px) !important;
            border: 1px solid rgba(255, 255, 255, 0.08) !important;
            box-shadow: 0 20px 40px rgba(0,0,0,0.4) !important;
            border-radius: 1.5rem !important;
          }
        }
      `}</style>
    </div>
  );
}